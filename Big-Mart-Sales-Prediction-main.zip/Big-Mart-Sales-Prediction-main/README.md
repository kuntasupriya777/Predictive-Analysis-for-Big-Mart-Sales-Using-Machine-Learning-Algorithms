# Big-Mart-Sales-Prediction
This is a used case project in Machine Learning i.e Big Mart Sales Prediction. 

## Machine learning model used - XGBOOST Regression Algorithm.

## Youtube video link :- https://youtu.be/eCC5yS68gmg
